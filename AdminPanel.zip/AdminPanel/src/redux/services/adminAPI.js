import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const adminApi = createApi({
  reducerPath: "adminApi",
  baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:8080/" }),
  endpoints: (builder) => ({

    getUsers: builder.query({
      query: () => "users",
      providesTags: ["Admin"],
    }),

    getSingleUser: builder.query({
      query: ({id}) => ({
        url: `admin/getSingleUser/${id}`,
      }),
      invalidatesTags: ['Admin'],
    }),

    addContent: builder.mutation({
      query: (contentData) => ({
        url: 'admin/contents',
        method: 'POST',
        body: contentData,
      }),
      invalidatesTags: ["Admin"],
    }),

    getContent: builder.query({
      query: () => "admin/getContents",
      providesTags: ["Admin"],
    }),

    getContentByID: builder.query({
      query: (id) => `admin/getcontent/${id}`,
      invalidatesTags: ["Admin"],
    }),

    registerSingledata: builder.query({
      query: ({ id }) => `admin/registerSingledata/${id}`,
      invalidatesTags: ["Admin"],
    }),

    adminLogin: builder.mutation({
      query: (data) => ({
        url: 'loginUser/loginUser',
        method: 'POST',
        body: data,
      }),
      invalidatesTags: ["Admin"],
    }),

    forgotPassword: builder.mutation({
      query: (user) => ({
        url: "admin/forgetPassword",
        method: "POST",
        body: user,
      }),
      invalidatesTags: ["Admin"],
    }),

    changePassword: builder.mutation({
      query: (user) => ({
        url: "admin/changePassword",
        method: "POST",
        body: user,
      }),
      invalidatesTags: ["Admin"],
    }),

    ForgetPasswordOtpVerify: builder.mutation({
      query: (body) => ({
        url: 'admin/forgetpasswordverifyOtp',
        method: 'POST',
        body
      })
    }),
    setNewPassword: builder.mutation({
      query: (body) => ({
        url: 'admin/setNewPassword',
        method: 'POST',
        body
      })
    }),

    updateContentById: builder.mutation({
      query: ({ id, updatedData }) => ({
        url: `admin/updatecontent/${id}`,
        method: 'POST',
        body: { updatedData },
      }),
      invalidatesTags: ['Admin'],
    }),

    adminReg: builder.mutation({
      query: ({ formData }) => ({
        url: 'admin',
        method: 'POST',
        body: { formData },
      }),
      invalidatesTags: ['Admin'],
    }),

    adminLogin: builder.mutation({
      query: ({ formData }) => ({
        url: 'admin/login',
        method: 'POST',
        body: { formData },
      }),
      invalidatesTags: ['Admin'],
    }),

    loginverifyOtp: builder.mutation({
      query: (body) => ({
        url: `admin/loginverifyOtp`,
        method: "POST",
        body
      })
    }),
    adminloginData: builder.mutation({
      query: (body) => ({
        url: 'admin/adminlogin',
        method: 'POST',
        body: body
      }),
      invalidatesTags: ['Admin'],
    }),

    getTwoFactorAuthentication: builder.mutation({
      query: (body) => ({
        url: 'admin/generateTwoFactorCode',
        method: 'POST',
        body
      }),
      invalidatesTags: ['Admin']
    }),
    twoFactorVerify: builder.mutation({
      query: (body) => ({
        url: 'admin/loginTwoFactorVerify',
        method: 'POST',
        body
      }),
      invalidatesTags: ['Admin']
    }),
    disableTwoFactorVerify: builder.mutation({
      query: (body) => ({
        url: 'admin/disableTwoFactor',
        method: 'POST',
        body
      }),
      invalidatesTags: ['Admin']
    }),

    loginTwoFactorVerify: builder.mutation({
      query: (body) => ({
        url: 'admin/loginTwoFactorVerify',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Admin'],
    }),
    
    forgotPattern: builder.mutation({
      query: (body) => ({
        url: 'admin/forgotPattern',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Admin'],
    }),

    oldPattern: builder.mutation({
      query: (body) => ({
          url: 'admin/oldPattern',
          method: 'POST',
          body: body
      }),
      invalidatesTags: ['Admin'],
  }),

  newPattern: builder.mutation({
      query: (body) => ({
          url: 'admin/newPattern',
          method: 'POST',
          body: body
      }),
      invalidatesTags: ['Admin'],
  }),

  verfiyEmail: builder.mutation({
    query: (body) => ({
      url: 'admin/verifyemail',
      method: 'POST',
      body,
    }),
    invalidatesTags: ['Admin'],
  }),
}),
    
  })
  








export const {
  useGetUsersQuery, useGetSingleUserQuery, useLoginTwoFactorVerifyMutation,useAddContentMutation, useAdminRegMutation, useChangePasswordMutation, useAdminLoginMutation, useGetContentQuery, useGetContentByIDQuery,  useForgotPasswordMutation, useLoginverifyOtpMutation, useOldPatternMutation, useNewPatternMutation,
  useUpdateContentByIdMutation, useAdminloginDataMutation,
  useGetTwoFactorAuthenticationMutation,
  useTwoFactorVerifyMutation, useForgetPasswordOtpVerifyMutation, useVerfiyEmailMutation, useForgotPatternMutation, useDisableTwoFactorVerifyMutation, useSetNewPasswordMutation
} = adminApi;
