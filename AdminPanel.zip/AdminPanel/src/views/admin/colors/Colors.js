import React from 'react'

const Colors = () => {
  return (
    <div>Colors</div>
  )
}

export default Colors;