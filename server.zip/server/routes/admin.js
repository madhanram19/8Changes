var express = require("express");
var router = express.Router();

const adminController = require('../controller/adminController');

router.post("/contents", adminController.contents);
router.get("/getContents", adminController.getContents);
router.get("/getContent/:id", adminController.getContent);
router.get ("/getsingleuser/:id", adminController.getsingleuser)
router.post("/updatecontent/:id", adminController.updatecontent);
router.get('/registerSingledata/:id', adminController.registerSingledata);
router.post('/', adminController.post);
router.post('/login', adminController.login);
router.post('/loginverifyOtp', adminController.loginverifyOtp);
router.post("/forgetPassword" , adminController.forgetPassword);
router.post("/forgetpasswordverifyOtp", adminController.forgetPasswordverifyOtp);
router.post("/setNewPassword", adminController.setNewPassword);
router.post('/changePassword', adminController.changePassword);
router.post ('/handleAdminLoginVerify', adminController.handleAdminLoginVerify)
router.post ('/generateTwoFactorCode', adminController.generateTwoFactorCode)
router.post('/loginTwoFactorVerify', adminController.loginTwoFactorVerify)
router.post ('/disableTwoFactorAuthentication', adminController.disableTwoFactorAuthentication);

router.post("/verifyemail", adminController.verifyemail);
router.post("/forgotPattern", adminController.forgotPattern)
router.post("/oldPattern", adminController.oldPattern);
router.post ("/newPattern", adminController.newPattern);
router.post('/loginTwoFactorVerify', adminController.loginTwoFactorVerify)


module.exports = router;